No optional tasks

